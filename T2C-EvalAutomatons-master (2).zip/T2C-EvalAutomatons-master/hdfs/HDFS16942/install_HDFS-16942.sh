# run this scripts on the server, reproducing HDFS16942 only need one server
# version: 3.1.3
# $1 should be the directory of T2C tool, $2 should be the directory of Hadoop source code
cd $2
git apply $1/experiments/reproduce/HDFS-16942/hook_HDFS-16942.patch
mvn clean package -Pdist -DskipTests -Dmaven.javadoc.skip=true -Dtar
version='3.1.3'
cp $1/experiments/reproduce/HDFS-16942/core-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
cp $1/experiments/reproduce/HDFS-16942/hdfs-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
# configure JAVA_HOME in hadoop-env.sh
sed -i 's/# export JAVA_HOME=/export JAVA_HOME=\/usr\/lib\/jvm\/java-1.8.0-openjdk-amd64\//g' hadoop-dist/target/hadoop-3.1.3/etc/hadoop/hadoop-env.sh