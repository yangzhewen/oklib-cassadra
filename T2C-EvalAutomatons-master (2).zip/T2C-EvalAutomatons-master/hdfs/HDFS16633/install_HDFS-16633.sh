# run this scripts on the server, reproducing HDFS16633 only need one server
# version: 3.1.2
# $1 should be the directory of T2C tool, $2 should be the directory of Hadoop source code
cd $2
git apply $1/experiments/reproduce/HDFS-16633/hook_HDFS-16633.patch
mvn clean package -Pdist -DskipTests -Dmaven.javadoc.skip=true -Dtar
version='3.1.2'
cp $1/experiments/reproduce/HDFS-16633/core-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
cp $1/experiments/reproduce/HDFS-16633/hdfs-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
# configure JAVA_HOME in hadoop-env.sh
sed -i 's/# export JAVA_HOME=/export JAVA_HOME=\/usr\/lib\/jvm\/java-1.8.0-openjdk-amd64\//g' hadoop-dist/target/hadoop-${version}/etc/hadoop/hadoop-env.sh