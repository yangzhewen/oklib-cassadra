# run this scripts on all nodes with the order of $3, $4, $5
cd $2
version='3.1.3'

cd hadoop-dist/target/hadoop-${version}/

# $3 is hostname of NFS server
if [ "$(hostname -s)" = $3 ]; then
  echo "this script should run on this host first"
  echo "install nfs-kernel-server"
  sudo apt-get install nfs-kernel-server
  echo "make configurations in /ect/exports"
  echo "make directory /ShareDir for sharing"
  sudo mkdir -p "/ShareDir"
  sudo chmod 755 "/ShareDir"
  sudo sh -c 'echo "/ShareDir *(rw,no_subtree_check,no_root_squash)" >> /etc/exports'
  echo "restart nfs-server" 
  sudo systemctl restart nfs-kernel-server

# $4 is hostname of standby namenode
elif [ "$(hostname -s)" = $4 ]; then
  echo "this script should run on this host second"
  echo "install NFS client"
  sudo apt-get install nfs-common
  echo "create shared directory '/ShareDir' and mount it"
  sudo mkdir -p "/ShareDir"
  sudo chmod -R 777 "/ShareDir"
  echo "mount /ShareDir"
  sudo mount $3:/ShareDir /ShareDir
  ./bin/hdfs namenode -format
  sleep 3
  ./sbin/hadoop-daemon.sh start namenode
  ./sbin/hadoop-daemon.sh start datanode

# $5 is hostname of active namenode
elif [ "$(hostname -s)" = $5 ]; then
  echo "this script should run on this host in the last"
  echo "install NFS client"
  sudo apt-get install nfs-common  
  echo "create shared directory '/ShareDir' and mount it"
  sudo mkdir -p "/ShareDir"
  sudo chmod -R 777 "/ShareDir"
  echo "mount /ShareDir"
  sudo mount $3:/ShareDir /ShareDir
  ./bin/hdfs namenode -bootstrapStandby 
  sleep 3
  ./sbin/hadoop-daemon.sh start namenode
  ./sbin/hadoop-daemon.sh start datanode
  ./bin/hdfs haadmin -getAllServiceState
  ./bin/hdfs haadmin -transitionToStandby nn1
  ./bin/hdfs haadmin -transitionToActive nn2
  ./bin/hdfs haadmin -getAllServiceState
  dd if=/dev/zero of=file_35M bs=1M count=35
  ./bin/hdfs dfs -put ./file_35M /
  ./bin/hdfs dfs -appendToFile ./file_35M /file_35M
  echo "sleep 20 seconds"
  sleep 20
  rm ./file_35M
  echo "now the bug should be triggered, you can check the content of hadoop-username-namenode-hostname.out in standby namenode."
  echo "There should be some output of the number of getPendingDataNodeMessageCount, and the number will not be reduced to 0."
fi