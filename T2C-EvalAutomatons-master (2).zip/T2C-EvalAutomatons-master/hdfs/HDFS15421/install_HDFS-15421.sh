# run this scripts on two namenodes. No need to run on NFS server.
# version: 3.1.3
# $1 should be the directory of T2C tool, $2 should be the directory of Hadoop source code
# cd $1
# # the some if the following instructions may change in the future, depending on the project's implementation
# bash ./run_engine.sh checkout conf/samples/hdfs-3.3.0.properties conf/samples/hdfs-collections/HDFS-15421.properties
cd $2
git clean -f
git checkout -f dd900259c421d6edd0b89a535a1fe08ada91735f
git apply $1/experiments/reproduce/HDFS-15421/hook_HDFS-15421.patch
mvn clean package -Pdist -DskipTests -Dmaven.javadoc.skip=true -Dtar
version=$(perl -ne 'print and last if s/.*<version>(.*)<\/version>.*/\1/;' < pom.xml)
cp $1/experiments/reproduce/HDFS-15421/core-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
cp $1/experiments/reproduce/HDFS-15421/hdfs-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
# configure JAVA_HOME in hadoop-env.sh
sed -i 's/# export JAVA_HOME=/export JAVA_HOME=\/usr\/lib\/jvm\/java-1.8.0-openjdk-amd64\//g' hadoop-dist/target/hadoop-${version}/etc/hadoop/hadoop-env.sh