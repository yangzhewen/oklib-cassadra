# run this scripts on two namenodes. No need to run on NFS server.
# version: 2.9.2
# $1 should be the directory of T2C tool, $2 should be the directory of Hadoop source code
cd $2
mvn clean package -Pdist -DskipTests -Dmaven.javadoc.skip=true -Dtar
version='2.9.2'
cp $1/experiments/reproduce/HDFS-14514/core-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
cp $1/experiments/reproduce/HDFS-14514/hdfs-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
cp $1/experiments/reproduce/HDFS-14514/kms-site.xml hadoop-dist/target/hadoop-${version}/etc/hadoop/
cp $1/experiments/reproduce/HDFS-14514/kms.passwd hadoop-dist/target/hadoop-${version}/share/hadoop/kms/tomcat/webapps/kms/WEB-INF/classes
# configure in hadoop-env.sh and kms-env.sh
sed -i 's/export JAVA_HOME=${JAVA_HOME}/JAVA_HOME=\/usr\/lib\/jvm\/java-1.8.0-openjdk-amd64\//g' hadoop-dist/target/hadoop-2.9.2/etc/hadoop/hadoop-env.sh
sed -i 's/# export KMS_LOG=${KMS_HOME}\/logs/export KMS_LOG=${KMS_HOME}\/logs/g' hadoop-dist/target/hadoop-2.9.2/etc/hadoop/kms-env.sh
sed -i 's/# export KMS_HTTP_PORT=16000/export KMS_HTTP_PORT=16000/g' hadoop-dist/target/hadoop-2.9.2/etc/hadoop/kms-env.sh
sed -i 's/# export KMS_ADMIN_PORT=`expr ${KMS_HTTP_PORT} + 1`/export KMS_ADMIN_PORT=`expr ${KMS_HTTP_PORT} + 1`/g' hadoop-dist/target/hadoop-2.9.2/etc/hadoop/kms-env.sh