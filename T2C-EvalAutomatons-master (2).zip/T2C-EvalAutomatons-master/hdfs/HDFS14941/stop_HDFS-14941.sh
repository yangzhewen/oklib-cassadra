# run this scripts on all nodes with the order of $3, $4, $5.
# This script will stop the HDFS HA cluster and NFS service
cd $2
version='3.1.3'

cd hadoop-dist/target/hadoop-${version}/

# $3 is hostname of NFS server
if [ "$(hostname -s)" = $3 ]; then
  echo "this script should run on this host last"
  echo "stop NFS server"
  sudo systemctl stop nfs-server
  sudo sed -i '/\/ShareDir \*(rw,no_subtree_check,no_root_squash)/d' /etc/exports
  sudo rm -r /ShareDir

# $4 is hostname of standby namenode
elif [ "$(hostname -s)" = $4 ]; then
  echo "this script should run before running on NFS server"
  ./sbin/hadoop-daemon.sh stop datanode
  ./sbin/hadoop-daemon.sh stop namenode
  echo "umount /ShareDir"
  sudo umount /ShareDir
  sudo service nfs-common stop
  sudo rm -r /ShareDir

# $5 is hostname of active namenode
elif [ "$(hostname -s)" = $5 ]; then
  echo "this script should run before running on NFS server"
  ./sbin/hadoop-daemon.sh stop datanode
  ./sbin/hadoop-daemon.sh stop namenode
  echo "umount /ShareDir"
  sudo umount /ShareDir
  sudo service nfs-common stop
  sudo rm -r /ShareDir
fi