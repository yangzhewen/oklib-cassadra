#single node should be sufficient for this case
cd ~/zookeeper
git checkout e3c1c87739b9fede7a0fcad0aaad0ca65b5101a9
git apply ~/T2C-EvalAutomatons/zookeeper/ZK-1754/hook_ZK-1754.patch
ant
