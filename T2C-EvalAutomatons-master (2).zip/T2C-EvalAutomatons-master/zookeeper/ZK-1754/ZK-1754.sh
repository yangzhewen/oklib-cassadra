bin/zkCli.sh <<EOF
  multi
EOF
