bin/zkCli.sh <<EOF
  create -e /q1 11
EOF
