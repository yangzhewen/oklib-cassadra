git clone https://github.com/apache/hbase.git
cd hbase
git checkout 2776bc0 #For patched version, checkout c5f4e84
mvn package -DskipTests