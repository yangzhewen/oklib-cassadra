#run this in /hbase  
./bin/start-hbase.sh
echo -e "\e[34mbuild an example table, downloading the jar file form my drive...\e[0m"
mkdir table_generator
cd table_generator
wget https://docs.google.com/uc\?export\=download\&confirm\=t\&id\=14bcy4bTuyuzoYtVRs-pfe__kwfF1OEYw
filename=$(ls)
echo $filename
mv "$filename" "Untitled.jar"
java -jar Untitled.jar
cd ..
echo "flush 'aa'" | ./bin/hbase shell
echo "alter 'aa', {NORMALIZATION_ENABLED => true}" | ./bin/hbase shell
echo "flush 'aa'" | ./bin/hbase shell
echo -e "\e[34mall set, wait for the normalizer to work\e[0m"
sleep 5m
echo -e "\e[34mshould repreduced now, checkout the log for the mergeplan or use the list_region 'aa' command in hbase shell in a while to see the merge result\e[0m"
./bin/stop-hbase.sh








# echo "Create 'tableName', {NAME => 'cf'}, {REGION_REPLICATION => 5}" | ./bin/hbase shell
# echo -e "\e[34mNext change the max size of file size, and this will be in infinite loop, this is where the bug appears. If patch is applied, this will success otherwise.\e[0m"
# echo "alter 'tableName', {NAME => 'cf', METHOD => 'table_att', MAX_FILESIZE => '1073741824'}" | ./bin/hbase shell
# ./bin/stop-hbase.sh
