test2 is the origin JAVA script of table generation (ignore)

Untitled.jar is the runnable file with all required library included (ignore, will be download by trigger_HBASE)

Install_HBASE is the script to install the HBASE with the bug version (run 1st)

trigger_HBASE is the script of trigger the issue(run 2nd)

then checkout the log and find the merge plan